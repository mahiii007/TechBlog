SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
CREATE SCHEMA IF NOT EXISTS `techblog` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;
USE `techblog` ;

-- -----------------------------------------------------
-- Table `techblog`.`categories`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `techblog`.`categories` (
  `cid` INT(11) NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(100) NOT NULL ,
  `description` VARCHAR(200) NULL DEFAULT NULL ,
  PRIMARY KEY (`cid`) )
ENGINE = InnoDB
AUTO_INCREMENT = 6
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `techblog`.`user`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `techblog`.`user` (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(45) NOT NULL ,
  `email` VARCHAR(45) NOT NULL ,
  `password` VARCHAR(45) NOT NULL ,
  `gender` VARCHAR(45) NOT NULL ,
  `about` VARCHAR(1000) NULL DEFAULT 'I am using TECHBLOG' ,
  `rdate` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ,
  `profile` VARCHAR(100) NULL DEFAULT 'default.png' ,
  PRIMARY KEY (`id`) ,
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) )
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `techblog`.`posts`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `techblog`.`posts` (
  `pid` INT(11) NOT NULL AUTO_INCREMENT ,
  `ptitle` VARCHAR(150) NOT NULL ,
  `pcontent` LONGTEXT NULL DEFAULT NULL ,
  `pcode` LONGTEXT NULL DEFAULT NULL ,
  `ppic` VARCHAR(100) NULL DEFAULT NULL ,
  `pdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
  `catid` INT(12) NULL DEFAULT NULL ,
  `userid` INT(11) NOT NULL ,
  PRIMARY KEY (`pid`) ,
  INDEX `catid_fk_idx` (`catid` ASC) ,
  INDEX `userid_fk_idx` (`userid` ASC) ,
  CONSTRAINT `catid_fk`
    FOREIGN KEY (`catid` )
    REFERENCES `techblog`.`categories` (`cid` )
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `userid_fk`
    FOREIGN KEY (`userid` )
    REFERENCES `techblog`.`user` (`id` )
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 6
DEFAULT CHARACTER SET = utf8;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
