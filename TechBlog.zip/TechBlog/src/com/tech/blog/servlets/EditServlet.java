package com.tech.blog.servlets;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.tech.blog.dao.UserDao;
import com.tech.blog.entities.Message;
import com.tech.blog.entities.User;
import com.tech.blog.helper.ConnectionProvider;
import com.tech.blog.helper.Helper;

@MultipartConfig
@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String email = request.getParameter("user_email");
		String name = request.getParameter("user_name");
		String password = request.getParameter("user_password");
		String about = request.getParameter("user_about");
		Part part = request.getPart("image");
		String imageName = part.getSubmittedFileName();

		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("current_user");

		user.setEmail(email);
		user.setName(name);
		user.setPassword(password);
		user.setAbout(about);
		String oldFile = user.getProfile();
		user.setProfile(imageName);

		Connection con = ConnectionProvider.getConnecion();
		UserDao userdao = new UserDao(con);
		int status = userdao.upadateUser(user);
		if (status != 0) {

			String path = request.getRealPath("/") + "pics" + File.separator + user.getProfile();
			String pathOldFile = request.getRealPath("/") + "pics" + File.separator + oldFile;

			if (!oldFile.equals("default.png")) {

				Helper.deleteFile(pathOldFile);
			}
			 if (Helper.saveFile(part.getInputStream(), path)) {
                 response.getWriter().println("Profile updated...");
                 Message msg = new Message("Profile details updated...", "success", "alert-success");
                 session.setAttribute("message", msg);

             } else {
                 
                 Message msg = new Message("Something went wrong..", "error", "alert-danger");
                 session.setAttribute("message", msg);
             }


		} else {
			response.getWriter().println("not updated...");
            Message msg = new Message("Something went wrong..", "error", "alert-danger");
            session.setAttribute("message", msg);

		}
		 response.sendRedirect("profile.jsp");

	}

}
