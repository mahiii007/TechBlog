package com.tech.blog.servlets;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tech.blog.dao.UserDao;
import com.tech.blog.entities.User;
import com.tech.blog.helper.ConnectionProvider;
@MultipartConfig
public class Register extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String check =req.getParameter("check");
		if(check==null)
		{
			resp.getWriter().println("Box not Checked...");
		}
		else
		{
			String username = req.getParameter("user_name");
			String email = req.getParameter("email");
			String password = req.getParameter("password");
			String gender =req.getParameter("gender");
			String about = req.getParameter("about");
			
			//Creating User Object
			User user = new User(username, email, password, gender, about);
			Connection con = ConnectionProvider.getConnecion();
			UserDao userdao = new UserDao(con);
			int status= userdao.saveUser(user);
			if(status!=0)
			{
				resp.getWriter().println("done...");
			}
			else
			{
				resp.getWriter().println("error...");
			}
		}
		
		
		
	
		
	}

}
