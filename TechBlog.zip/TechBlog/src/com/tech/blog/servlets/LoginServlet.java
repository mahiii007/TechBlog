package com.tech.blog.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.blog.dao.UserDao;
import com.tech.blog.entities.Message;
import com.tech.blog.entities.User;
import com.tech.blog.helper.ConnectionProvider;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Login Servlet</title>");
		out.println("</head>");
		out.println("<body>");

		String email = request.getParameter("email");
		String password = request.getParameter("password");

		Connection con = ConnectionProvider.getConnecion();
		UserDao userdao = new UserDao(con);
		User user = userdao.getuser(email, password);

		if (user == null) {

			Message msg = new Message("Invalid Details..!Try With Another", "error", "alert-danger");
			HttpSession session = request.getSession();
			session.setAttribute("message", msg);
			response.sendRedirect("login_page.jsp");

		} else {
			HttpSession session = request.getSession();
			session.setAttribute("current_user", user);
			response.sendRedirect("profile.jsp");
		}

		out.println("</body>");
		out.print("</html>");
	}

}
