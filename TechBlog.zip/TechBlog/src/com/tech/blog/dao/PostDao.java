package com.tech.blog.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.tech.blog.entities.Category;
import com.tech.blog.entities.Post;

public class PostDao {
	private Connection con;

	public PostDao(Connection con) {
		this.con = con;
	}

	public ArrayList<Category> getAllCategories() {
		ArrayList<Category> list = new ArrayList<>();

		try {

			String query = " select * from categories ";
			PreparedStatement pstmt = con.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				int cid = rs.getInt("cid");
				String name = rs.getString("name");
				String description = rs.getString("description");
				Category category = new Category(cid, name, description);
				list.add(category);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public int savePost(Post post) {
		int status = 0;
		try {

			String query = " insert into posts(ptitle,pcontent,pcode,ppic,catid,userid) values(?,?,?,?,?,?) ";
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, post.getpTitle());
			pstmt.setString(2, post.getpContent());
			pstmt.setString(3, post.getpCode());
			pstmt.setString(4, post.getPpic());
			pstmt.setInt(5, post.getCatid());
			pstmt.setInt(6, post.getUserid());
			status = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return status;
	}

	public List<Post> getAllPosts() {

		List<Post> list = new ArrayList<>();

		try {

			PreparedStatement pstmt = con.prepareStatement(" select * from posts order by pid desc ");

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				int pid = rs.getInt("pid");
				String pTitle = rs.getString("ptitle");
				String pContent = rs.getString("pcontent");
				String pCode = rs.getString("pcode");
				String pPic = rs.getString("ppic");
				Timestamp date = rs.getTimestamp("pdate");
				int catId = rs.getInt("catid");
				int userId = rs.getInt("userid");
				Post post = new Post(pid, pTitle, pContent, pCode, pPic, date, catId, userId);

				list.add(post);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<Post> getPostByCatId(int catid) {
		List<Post> list = new ArrayList<>();

		try {

			PreparedStatement pstmt = con.prepareStatement(" select * from posts where catid=? ");
			pstmt.setInt(1, catid);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {

				int pid = rs.getInt("pid");
				String pTitle = rs.getString("ptitle");
				String pContent = rs.getString("pcontent");
				String pCode = rs.getString("pcode");
				String pPic = rs.getString("ppic");
				Timestamp date = rs.getTimestamp("pdate");

				int userId = rs.getInt("userid");
				Post post = new Post(pid, pTitle, pContent, pCode, pPic, date, catid, userId);

				list.add(post);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	  public Post getPostByPostId(int postId) {
	        Post post = null;
	        String q = "select * from posts where pid=?";
	        try {
	            PreparedStatement p = this.con.prepareStatement(q);
	            p.setInt(1, postId);

	            ResultSet set = p.executeQuery();

	            if (set.next()) {

	                int pid = set.getInt("pid");
	                String pTitle = set.getString("ptitle");
	                String pContent = set.getString("pcontent");
	                String pCode = set.getString("pcode");
	                String pPic = set.getString("ppic");
	                Timestamp date = set.getTimestamp("pdate");
	                int cid=set.getInt("catid");
	                int userId = set.getInt("userid");
	                post = new Post(pid, pTitle, pContent, pCode, pPic, date, cid, userId);

	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return post;
	    }

}
